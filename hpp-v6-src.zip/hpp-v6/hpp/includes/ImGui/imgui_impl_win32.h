#pragma once

IMGUI_IMPL_API bool     ImGui_ImplWin32_Init(HWND hwnd);
IMGUI_IMPL_API void     ImGui_ImplWin32_Shutdown();
IMGUI_IMPL_API void     ImGui_ImplWin32_NewFrame();
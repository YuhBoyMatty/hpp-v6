class CGlowPlayers
{
public:
	bool Draw(cl_entity_s* pGameEntity);

private:
	bool IsPlayer(int index);
};
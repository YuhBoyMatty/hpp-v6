#include "framework.h"

void CDrawWorld::Overlay()
{

}
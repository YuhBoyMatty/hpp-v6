class CDrawWorld
{
public:
	void Overlay();

private:
};
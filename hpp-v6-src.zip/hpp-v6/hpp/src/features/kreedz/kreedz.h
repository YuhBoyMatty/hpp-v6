class CKreedz
{
public:
	void Run();
};
extern std::map<std::string, xcommand_t> g_ClientCommandsMap;

bool HookCommands();
void UnHookCommands();
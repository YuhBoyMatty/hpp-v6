void HookControllerGL();
bool HookOpenGL();
void UnHookOpenGL();
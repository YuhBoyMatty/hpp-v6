class CMenuThemes
{
public:
	void SetDefaultDarkTheme();
};
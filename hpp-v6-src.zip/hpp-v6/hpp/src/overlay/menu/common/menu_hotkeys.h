class CMenuHotkeys
{
public:
	bool Is(std::string key);
};